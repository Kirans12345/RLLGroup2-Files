package testPages;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import pageFactory.*;

public class Search_TRN_View_Checking_Test extends TestBase {

	Search_TRN_ViewChecking_Page strn;
	SignInNew sip;
	
	@BeforeMethod
	public void setup()
	{
		WebDriver driver = null;
		sip=new SignInNew(driver);
		strn = new Search_TRN_ViewChecking_Page(driver);
		sip.signIn();
	}
	
	
	public  void testSearchTRN_ViewChecking()
	{
		//String expected_txt = "No matching records found";
		strn.clickonCheckingPage();
		strn.searchtrn("845586594");
	
	}
	
	@AfterMethod
	public void logout()
	{
		sip.logout();
	}
}