package testPages;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageFactory.*;

public class TestTransferBetAccountPage extends TestBase{
	SignInNew ps;
	TransferBwAcounts pt;
	@BeforeTest
	public void setup() {
		getDriver();
		ps = new SignInNew(driver);
		pt=new TransferBwAcounts(driver);
	}
	

	@Test(priority='1')
	public void getLogin() {
		ps.signIn();
	}

	@Test(priority='2')
	public void clickTransferBtn() {
		pt.transferMoney();
	}

	@Test(priority='3')
	public void chooseFromAccount() {
		pt.clickFrom();
	}

	@Test(priority='4')
	public void chooseToAccount() {
		pt.clickTo();
	}

	@Test(priority='5')
	public void enterMoney(String money) {
		pt.enterAmount(money);
	}
	

	@Test(priority='6')
	public void submitDone() {
		pt.clickSubmit();
		
		if (pt.sucessDisplay()) {
			String result="View Savings Accounts";
			String expectedResult=pt.validate_transfer_sussceful();
		assertEquals(expectedResult, result);
		
		}
		else {
			String result="Error";
			String expectedResult=pt.validate_transfer_unsusscefull();
			assertEquals(expectedResult, result);
		}
	}
}