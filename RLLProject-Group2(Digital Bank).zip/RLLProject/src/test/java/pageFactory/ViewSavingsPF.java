package pageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ViewSavingsPF {

	
 WebDriver driver;
	
	@FindBy(id="username")
    static WebElement TxtBox_UserName;
	
	

	@FindBy(id="password")
    static WebElement TxtBox_Password;
    
    
    
    @FindBy(xpath="//*[@id=\"page-title\"]")
    static WebElement TestViewSavings;
 
    

	@FindBy(id="submit")
    static WebElement Btn_Login;
	
	
	 @FindBy(xpath = "//input[@class='form-control form-control-sm']")
	 static WebElement Form_fill;


		@FindBy(xpath="//a[@class='nav-link'][normalize-space()='Create Data']")
			    static WebElement createdata;
			@FindBy(xpath ="//img[@alt='User Avatar']")
	 
			static WebElement menu;
			 
			 
			@FindBy(xpath = "//a[@id='savings-menu'][@class='dropdown-toggle'][normalize-space()='Savings']")
		    static WebElement savings;
		
			 
			@FindBy(xpath = "//a[@id='view-savings-menu-item'][normalize-space()='View Savings']")
		    static WebElement savingsView;
			
			@FindBy(xpath = "//input[@class='form-control form-control-sm']")
			static WebElement SearchTransaction;
			
	 
	
	

			public void clickTheCreateData() {
			
			
			createdata.click();
			}

			public void clickthemenu() {
				
				
				menu.click();
			
			
		}

			

			public void clickTheSavings() {
			
			
			savings.click();
			}
			
			
			

			public void clickTheViewSavings() {
			
			
			savingsView.click();
			}
		
			
			public void searchTransactionDetails(String u) {
				
				SearchTransaction.sendKeys(u);
				
			}
			
			
			

 
	
	public void enterUsername(String s)
	{
		
		
		TxtBox_UserName.sendKeys(s);
	}
	public void enterPassword(String P)
	{
		
		
		TxtBox_UserName.sendKeys(P);
	}
	 
	public void enterLoginDetails(String u, String y) {
		
		
		TxtBox_UserName.sendKeys(u);
		TxtBox_Password.sendKeys(y);
		Btn_Login.click();
		
		
		
		
		
		
	}
	
	public ViewSavingsPF(WebDriver driver) {
	
		this.driver = driver;
		PageFactory.initElements(driver, this);
	
	
	}
	 

	
	
	 
	
	
}