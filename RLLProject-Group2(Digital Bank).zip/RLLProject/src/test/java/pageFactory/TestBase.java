package pageFactory;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {

	public static WebDriver driver;
	public static ExtentReports er;
	public static ExtentTest et;	
	
	@BeforeClass
	public static void setUp() {
		
		if (driver == null) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("http://dbankdemo.com/bank/login");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			
		}
	}

	@AfterClass
	public static void teardown()
	{
		driver.quit();
	}

	@BeforeTest
	public void getnameMethod(ITestContext context)
	{
		et=	er.createTest(context.getName());
	}

	// this method will be executed before suite begins its execution

	@BeforeSuite  
	public void InitalizeExtentReport()
	{
		ExtentSparkReporter sparkreporter = new ExtentSparkReporter("reportpom.html");
		er = new ExtentReports();
		er.attachReporter(sparkreporter);
		// on the report display more information about OS, browser, java etc
		er.setSystemInfo("OS", System.getProperty("os.name"));
		er.setSystemInfo("JAVA", System.getProperty("java.version"));

	}

	@AfterSuite
	public void generateReports() throws IOException
	{
		er.flush();
		Desktop.getDesktop().browse(new File("reportpom.html").toURI());
	}


	@AfterMethod()
	public void generateTestStatus(Method m,ITestResult result)
	{
		if(result.getStatus() == ITestResult.FAILURE )
		{
			et.fail(result.getThrowable());
		}
		else if (result.getStatus() == ITestResult.SUCCESS) {
			et.pass(m.getName() + " is passed");
		}
	}
	
	public static WebDriver getDriver() {
		return driver;
	}

}
