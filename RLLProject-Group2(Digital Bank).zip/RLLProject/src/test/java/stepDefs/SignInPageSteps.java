package stepDefs;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageFactory.SignInPage;
import pageFactory.TestBase;
import utilities.ExcelReader;

public class SignInPageSteps {
    TestBase b;
    SignInPage s;
    SoftAssert softAssert = new SoftAssert();
    Logger logger = LogManager.getLogger(SignInPageSteps.class);
    
    @Given("I open my dbankdemo website on chrome browser")
    public void open_Browser(){
        logger.info("User is on SignIn page");
    	TestBase.setUp();
    	WebDriver driver=TestBase.getDriver();
    	s=new SignInPage(driver);
    	driver.get("http://dbankdemo.com/bank/login");
    	String actual="Digital Bank";
    	String expected=TestBase.getDriver().getTitle();
    	System.out.println(expected);
    	softAssert.assertNotEquals(actual, expected);
    	//Assert.assertEquals(actual, expected);
    }

    @When("I entered the login credentials from Excel {string} and i clicked on signin")
    public void iHaveValidLoginCredentialsFromExcel(String excelFilePath) throws IOException {
    	
        //ExcelReader excelReader = new ExcelReader();
        Object[][] testData = ExcelReader.getTestData(excelFilePath);

        for (Object[] row : testData) {
            String username = String.valueOf(row[0]); // Because username is in the first column
            String password = String.valueOf(row[1]); // Because password is in the second column

            System.out.println("Username: " + username);
            System.out.println("Password: " + password);

            //s = new SignInPage(BaseClass.getDriver());
            logger.info("Taken Data from excel");
            s.signIn(username, password);
            //soft.assertTrue(s.loginSuccsessfull(), "Assert failed- Invalid Credentials");

           try {
                if (s.loginSuccsessfull()) {
                    logger.info("User Logged in Successfully");
                    //login is successful(pass)
                	}
           } catch (Exception e) {
               // Handle any exceptions during login attempt
                logger.info("Enter valid username and password");
                e.getMessage();
            }
            
            
            try {
                s.logout();
            } catch (Exception ex) {
                ex.getMessage();
            }
           }
        }
    
           

    @Then("I close my browser")
    public void iEnterTheLoginCredentials() {
    	String actual=TestBase.getDriver().getTitle();
    	System.out.println(actual);
    	System.out.println(SignInPage.getMessage());
    	//System.out.println(actual);
    	String expected="Digital Bank";
    	Assert.assertEquals(actual, expected);
        logger.info("Sign in module completed");
    	//TestBase.teardown();
    }
}
