package stepDefs;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageFactory.*;
import pageFactory.TestBase;
public class DirectPaymentToVisasteps extends TestBase {
	
	private static final Logger logger = LogManager.getLogger(DirectPaymentToVisasteps.class);
	SoftAssert s=new SoftAssert();
	DirectPaymentToVisa dv ;
	
	
	@When("I am on the dbankwebpage")
	public void i_am_on_the_dbankwebpage() {
		logger.info("I am on DBankDemo homepage");
		
           TestBase.setUp();
           WebDriver driver=TestBase.getDriver();
           driver.get("http://dbankdemo.com/bank/login");
          dv = new DirectPaymentToVisa(driver);
		
	}

	@Then("I sign in using valid credentials")
	public void i_sign_in_using_valid_credentials() {
		logger.info("Signin successfully");
		driver.findElement(By.id("username")).sendKeys("kirans@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Kiran4301@S");
		driver.findElement(By.id("submit")).click();
		
	  
	}

	@Then("I enter on the Home Page")
	public void i_enter_on_the_home_page() {
		logger.info("i am on the Homepage");
		System.out.println("title of the is page is : "+ driver.getTitle());
		
	}

	@Then("I  click on Direct Transer to visa")
	public void i_click_on_direct_transer_to_visa() throws InterruptedException {
		logger.info("Clicked on Direct Transfer to visa");
		Thread.sleep(5000);
		dv.VisaDirectTransfer();
//		boolean b=dv.apiErrorMeassage();
//		   if(b) {
//			   Assert.fail("Please raise a tickect Current Api is not working ...");
//		   }
	}

	@Then("I select the visa account number")
	public void i_select_the_visa_account_number() throws InterruptedException {
		logger.info("Selecting the visa account number");
	    Thread.sleep(5000);

		dv.VisaAccountNumber();
	}

	@Then("I give the transfer amount as {string}")
	public void i_give_the_transfer_amount_as(String Amount) {
		logger.info("Giving the transfer amount");
	    dv.enterAmount(Amount);
	}

	@Then("I click on  submit")
	public void i_click_on_submit() {
		logger.info("click on submit");
	    dv.clickSubmit();
	    boolean b=dv.apiErrorMeassage();
		   if(b) {
			   Assert.fail("Please raise a tickect Current Api is not working ...");
		   }
	    
	}
	@Then("I will get result as {string}")
	public void i_will_get_result_as(String result) {
		String expected = result;
		String actualText = dv.Message();
	    Assert.assertEquals(actualText, expected);
	   //String expected = Base.getDriver().getTitle();
	   //String actual = result;
	   //Assert.assertEquals(actual, expected);
	   //System.out.println(actual);

	   
	}
	
	   
	   
	   
	
}